# Auth Website

Kullanıcı kayıt ve giriş sistemi.

## Kurulum

```bash
npm install
npm start
```

## Özellikler

- Kullanıcı kayıt/giriş
- Admin paneli
- SQLite veritabanı
- bcrypt şifreleme
